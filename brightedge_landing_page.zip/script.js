
function handleSubmit(event) {
  event.preventDefault();
  alert("Thanks for reaching out! We'll get back to you soon.");
}
